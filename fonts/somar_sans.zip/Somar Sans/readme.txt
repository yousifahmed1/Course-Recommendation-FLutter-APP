Somar Sans is free to use in your commercial and personal projects.

Appreciate and follow:
https://www.behance.net/baianat-type
